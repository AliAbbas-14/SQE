package com.testing;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

import com.calculator.Calculator;

class CalculatorDataDrivenTest {

    Calculator calc = new Calculator();

    @ParameterizedTest
    @CsvFileSource(resources = "/CalculatorDataDrivenTest.csv", numLinesToSkip = 1)
    void testCalculator(double a, double b, String operation, String expected) {
        String actual;

        double result = 0;

        switch (operation) {
            case "add":
                result = calc.add(a, b);
                break;
            case "sub":
                result = calc.sub(a, b);
                break;
            case "mul":
                result = calc.mul(a, b);
                break;
            case "div":
                result = calc.div(a, b);
                break;
            default:
                fail("Invalid operation in CSV: " + operation);
        }

        actual = String.valueOf(result);
        
          
         assertEquals(expected, actual);
    }
}
