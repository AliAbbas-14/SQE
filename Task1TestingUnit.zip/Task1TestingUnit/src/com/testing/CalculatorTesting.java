package com.testing;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.calculator.Calculator;

class CalculatorTesting {

	@Test
	void add() {
		assertEquals(9,new Calculator().add(4,5));
	}
	
	@Test
	void div() {
		assertEquals("invalid",new Calculator().div(4,0));
	}

}