package com.testing;

import org.junit.jupiter.api.Test;

class ParallelVerifyTest {

    @Test
    void test1() throws InterruptedException {
        System.out.println("Running test1 on " + Thread.currentThread().getName());
        Thread.sleep(500);
    }

    @Test
    void test2() throws InterruptedException {
        System.out.println("Running test2 on " + Thread.currentThread().getName());
        Thread.sleep(500);
    }

    @Test
    void test3() throws InterruptedException {
        System.out.println("Running test3 on " + Thread.currentThread().getName());
        Thread.sleep(500);
    }
}
