package com.mvp.unitTesting;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.mvp.testing.CalculatorModel;

class CalculatorModelTesting {
	  private CalculatorModel model;

	    @BeforeEach
	    void setup() {
	        model = new CalculatorModel();
	    }

	    // ---------------------- ADD ---------------------- //
	    /**
	     * ECP (Positive, Negative, Mixed, Zero)
	     * BVA (Large values, near-zero values)
	     */
	    @Test
	    void add_withPositiveNumbers_returnsSum() {
	        assertEquals(8, model.add(5, 3));
	    }

	    @Test
	    void add_withNegativeNumbers_returnsSum() {
	        assertEquals(-8, model.add(-5, -3));
	    }

	    @Test
	    void add_withMixedSigns_returnsCorrectValue() {
	        assertEquals(2, model.add(5, -3));
	    }

	    @Test
	    void add_withZero_returnsSameValue() {
	        assertEquals(7, model.add(7, 0));
	    }

	    @Test
	    void add_withLargeValues_handlesBoundary() {
	        assertEquals(2000000000, model.add(1000000000, 1000000000));
	    }

	    @Test
	    void add_withDecimalValues_returnsAccurateSum() {
	        assertEquals(8.7, model.add(5.2, 3.5), 0.0001);
	    }

	    // ---------------------- SUB ---------------------- //
	    /**
	     * ECP (Positive, Negative, Mixed)
	     * BVA (Cross-zero, large values)
	     */
	    @Test
	    void sub_withPositiveNumbers_returnsDifference() {
	        assertEquals(2, model.sub(5, 3));
	    }

	    @Test
	    void sub_withNegativeNumbers_returnsDifference() {
	        assertEquals(-2, model.sub(-5, -3));
	    }

	    @Test
	    void sub_withMixedSigns_returnsCorrectValue() {
	        assertEquals(8, model.sub(5, -3));
	    }

	    @Test
	    void sub_crossZeroBoundary_returnsNegative() {
	        assertEquals(-1, model.sub(0, 1));
	    }

	    @Test
	    void sub_withLargeNumbers_boundaryCheck() {
	        assertEquals(0, model.sub(1000000000, 1000000000));
	    }

	    @Test
	    void sub_withDecimalNumbers_returnsPreciseValue() {
	        assertEquals(1.5, model.sub(5.5, 4.0), 0.0001);
	    }

	    // ---------------------- MUL ---------------------- //
	    /**
	     * ECP (Positive, Negative, Zero)
	     * BVA (Large value product, fractional numbers)
	     */
	    @Test
	    void mul_withPositiveNumbers_returnsProduct() {
	        assertEquals(15, model.mul(3, 5));
	    }

	    @Test
	    void mul_withZero_returnsZero() {
	        assertEquals(0, model.mul(0, 5));
	    }

	    @Test
	    void mul_withNegativeNumbers_returnsPositive() {
	        assertEquals(9, model.mul(-3, -3));
	    }

	    @Test
	    void mul_withMixedSigns_returnsNegative() {
	        assertEquals(-15, model.mul(-3, 5));
	    }

	    @Test
	    void mul_withLargeNumbers_boundaryCheck() {
	        assertEquals(1000000000000L, model.mul(1000000, 1000000));
	    }

	    @Test
	    void mul_withDecimalNumbers_returnsAccurateProduct() {
	        assertEquals(7.5, model.mul(2.5, 3.0), 0.0001);
	    }

	    // ---------------------- DIV ---------------------- //
	    /**
	     * ECP (Positive/Negative division, zero numerator)
	     * BVA (Division by zero (exception), small fractions)
	     */
	    @Test
	    void div_withPositiveNumbers_returnsQuotient() {
	        assertEquals(5, model.div(10, 2));
	    }

	    @Test
	    void div_withNegativeNumbers_returnsPositive() {
	        assertEquals(5, model.div(-10, -2));
	    }

	    @Test
	    void div_withMixedSigns_returnsNegative() {
	        assertEquals(-5, model.div(10, -2));
	    }

	    @Test
	    void div_withZeroNumerator_returnsZero() {
	        assertEquals(0, model.div(0, 10));
	    }

	    @Test
	    void div_withSmallFraction_returnsAccurateValue() {
	        assertEquals(0.5, model.div(1, 2), 0.0001);
	    }

	    @Test
	    void div_withZeroDenominator_throwsException() {
	        assertThrows(ArithmeticException.class, () -> model.div(10, 0));
	    }
}
