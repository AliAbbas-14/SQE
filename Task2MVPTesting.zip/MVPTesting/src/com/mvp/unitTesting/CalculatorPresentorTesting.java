package com.mvp.unitTesting;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.awt.event.ActionEvent;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.mvp.testing.CalculatorModel;
import com.mvp.testing.CalculatorPresentor;
import com.mvp.testing.CalculatorView;

class CalculatorPresentorTesting {

    private CalculatorModel model;
    private CalculatorView view;
    private CalculatorPresentor presenter;

    @BeforeEach
    void setup() {
        model = new CalculatorModel();
        view = new CalculatorView();
        presenter = new CalculatorPresentor(model, view);
    }

    // -------------------- ADD TESTS --------------------
    @Test
    void add_withPositiveNumbers_returnsSum() {
        view.appendOperand1("5");
        view.appendOperand2("3");
        presenter.actionPerformed(new ActionEvent(this, 0, "Add"));
        assertEquals("8.0", view.getResultText());
    }

    @Test
    void add_withNegativeNumbers_returnsSum() {
        view.appendOperand1("-4");
        view.appendOperand2("-6");
        presenter.actionPerformed(new ActionEvent(this, 0, "Add"));
        assertEquals("-10.0", view.getResultText());
    }

    @Test
    void add_withZero_returnsSameValue() {
        view.appendOperand1("5");
        view.appendOperand2("0");
        presenter.actionPerformed(new ActionEvent(this, 0, "Add"));
        assertEquals("5.0", view.getResultText());
    }

    @Test
    void add_withLargeValues_handlesBoundary() {
        view.appendOperand1(String.valueOf(Double.MAX_VALUE / 2));
        view.appendOperand2(String.valueOf(Double.MAX_VALUE / 2));
        presenter.actionPerformed(new ActionEvent(this, 0, "Add"));
        assertNotNull(view.getResultText()); // overflow possible
    }

    @Test
    void add_withInvalidInput_showsError() {
        view.appendOperand1("a");
        view.appendOperand2("2");
        presenter.actionPerformed(new ActionEvent(this, 0, "Add"));
        assertEquals("Error: Invalid input", view.getResultText());
    }

    // -------------------- SUB TESTS --------------------
    @Test
    void sub_withPositiveNumbers_returnsDifference() {
        view.appendOperand1("10");
        view.appendOperand2("3");
        presenter.actionPerformed(new ActionEvent(this, 0, "Sub"));
        assertEquals("7.0", view.getResultText());
    }

    @Test
    void sub_withNegativeNumbers_returnsCorrect() {
        view.appendOperand1("-10");
        view.appendOperand2("-5");
        presenter.actionPerformed(new ActionEvent(this, 0, "Sub"));
        assertEquals("-5.0", view.getResultText());
    }

    @Test
    void sub_withZeroOperand_returnsSame() {
        view.appendOperand1("5");
        view.appendOperand2("0");
        presenter.actionPerformed(new ActionEvent(this, 0, "Sub"));
        assertEquals("5.0", view.getResultText());
    }

    @Test
    void sub_crossesZero_boundaryValue() {
        view.appendOperand1("2");
        view.appendOperand2("5");
        presenter.actionPerformed(new ActionEvent(this, 0, "Sub"));
        assertEquals("-3.0", view.getResultText());
    }

    @Test
    void sub_withInvalidInput_showsError() {
        view.appendOperand1("a");
        view.appendOperand2("3");
        presenter.actionPerformed(new ActionEvent(this, 0, "Sub"));
        assertEquals("Error: Invalid input", view.getResultText());
    }

    // -------------------- MUL TESTS --------------------
    @Test
    void mul_withPositiveNumbers_returnsProduct() {
        view.appendOperand1("3");
        view.appendOperand2("5");
        presenter.actionPerformed(new ActionEvent(this, 0, "Mul"));
        assertEquals("15.0", view.getResultText());
    }

    @Test
    void mul_withZero_returnsZero() {
        view.appendOperand1("0");
        view.appendOperand2("5");
        presenter.actionPerformed(new ActionEvent(this, 0, "Mul"));
        assertEquals("0.0", view.getResultText());
    }

    @Test
    void mul_withNegativeNumbers_returnsPositive() {
        view.appendOperand1("-4");
        view.appendOperand2("-2");
        presenter.actionPerformed(new ActionEvent(this, 0, "Mul"));
        assertEquals("8.0", view.getResultText());
    }

    @Test
    void mul_withPositiveAndNegative_returnsNegative() {
        view.appendOperand1("5");
        view.appendOperand2("-3");
        presenter.actionPerformed(new ActionEvent(this, 0, "Mul"));
        assertEquals("-15.0", view.getResultText());
    }

    @Test
    void mul_withLargeValues_boundaryCheck() {
        view.appendOperand1("1000000");
        view.appendOperand2("1000000");
        presenter.actionPerformed(new ActionEvent(this, 0, "Mul"));
        assertEquals("1.0E12", view.getResultText()); // scientific notation
    }

    // -------------------- DIV TESTS --------------------
    @Test
    void div_withPositiveNumbers_returnsQuotient() {
        view.appendOperand1("10");
        view.appendOperand2("2");
        presenter.actionPerformed(new ActionEvent(this, 0, "Div"));
        assertEquals("5.0", view.getResultText());
    }

    @Test
    void div_withNegativeNumbers_returnsPositive() {
        view.appendOperand1("-10");
        view.appendOperand2("-2");
        presenter.actionPerformed(new ActionEvent(this, 0, "Div"));
        assertEquals("5.0", view.getResultText());
    }

    @Test
    void div_withZeroNumerator_returnsZero() {
        view.appendOperand1("0");
        view.appendOperand2("5");
        presenter.actionPerformed(new ActionEvent(this, 0, "Div"));
        assertEquals("0.0", view.getResultText());
    }

    @Test
    void div_withZeroDenominator_doesNotCrash() {
        view.appendOperand1("5");
        view.appendOperand2("0");
        assertDoesNotThrow(() -> presenter.actionPerformed(new ActionEvent(this, 0, "Div")));
    }

    @Test
    void div_withInvalidInput_showsError() {
        view.appendOperand1("a");
        view.appendOperand2("2");
        presenter.actionPerformed(new ActionEvent(this, 0, "Div"));
        assertEquals("Error: Invalid input", view.getResultText());
    }
}
