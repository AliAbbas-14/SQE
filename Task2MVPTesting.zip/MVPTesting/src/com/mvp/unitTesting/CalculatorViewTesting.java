package com.mvp.unitTesting;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.mvp.testing.CalculatorView;

class CalculatorViewTesting {

    private CalculatorView view;

    @BeforeEach
    void setup() {
        view = new CalculatorView();
    }

    // --------- Operand 1 Tests ---------

    @Test
    void appendOperand1_withSingleDigit_updatesCorrectly() {
        assertEquals("5", view.appendOperand1("5"));
    }

    @Test
    void appendOperand1_withMultipleDigits_concatenatesProperly() {
        view.appendOperand1("1");
        assertEquals("12", view.appendOperand1("2"));
    }

    @Test
    void appendOperand1_withEmptyString_doesNotChange() {
        view.appendOperand1("7");
        assertEquals("7", view.appendOperand1(""));
    }

    @Test
    void appendOperand1_withBoundaryLength_handlesCorrectly() {
        StringBuilder largeInput = new StringBuilder();
        for (int i = 0; i < 50; i++) largeInput.append("9");
        String result = view.appendOperand1(largeInput.toString());
        assertTrue(result.length() >= 50);
    }

    @Test
    void getOperand1_initiallyEmpty_returnsEmptyString() {
        assertEquals("", view.getOperand1());
    }

    // --------- Operand 2 Tests ---------

    @Test
    void appendOperand2_withSingleDigit_updatesCorrectly() {
        assertEquals("3", view.appendOperand2("3"));
    }

    @Test
    void appendOperand2_withMultipleDigits_concatenatesProperly() {
        view.appendOperand2("4");
        assertEquals("45", view.appendOperand2("5"));
    }

    @Test
    void appendOperand2_withEmptyString_doesNotChange() {
        view.appendOperand2("6");
        assertEquals("6", view.appendOperand2(""));
    }

    @Test
    void getOperand2_initiallyEmpty_returnsEmptyString() {
        assertEquals("", view.getOperand2());
    }

    // --------- Result Field Tests ---------

    @Test
    void updateResult_withValidNumber_displaysCorrectResult() {
        view.updateResult("10");
        view.updateResult("20");
        assertDoesNotThrow(() -> view.updateResult("20"));
    }

    @Test
    void updateResult_withEmptyString_doesNotThrowError() {
        assertDoesNotThrow(() -> view.updateResult(""));
    }

    @Test
    void updateResult_withLongString_handlesWithoutCrash() {
        String longResult = "12345678901234567890";
        assertDoesNotThrow(() -> view.updateResult(longResult));
    }
}