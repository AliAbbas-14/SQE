package com.mvp.testing;

import java.awt.Button;
import java.awt.Frame;
import java.awt.TextField;
import java.awt.FlowLayout;
import java.awt.Label;
import java.awt.event.ActionListener;


/**
 * The View, responsible for the user interface.
 * This class creates and manages the AWT components (TextFields, Buttons).
 */
public class CalculatorView extends Frame {
	private TextField txtOp1;
	private TextField txtOp2;
	private TextField txtRes;
	
	private Button btnAdd, btnSub, btnMul, btnDiv, btnZero, btnOne, btnTwo, btnThree,
	        btnFour, btnFive, btnSix, btnSeven, btnEight, btnNine;
	
	public CalculatorView() {
		// Set the layout for the frame
		setLayout(new FlowLayout());

		// Initialize AWT components
		txtOp1 = new TextField(10);
		txtOp2 = new TextField(10);
		txtRes = new TextField(10);
		// The result TextField should be non-editable by the user
		txtRes.setEditable(false);
		
		btnAdd = new Button("+");
		btnAdd.setActionCommand("Add");
		
		btnSub = new Button("-");
		btnSub.setActionCommand("Sub");
		
		btnMul = new Button("*");
		btnMul.setActionCommand("Mul");
		
		btnDiv = new Button("/");
		btnDiv.setActionCommand("Div");
		
		btnZero = new Button("0");
		btnZero.setActionCommand("0");
		
		btnOne = new Button("1");
		btnOne.setActionCommand("1");
		
		btnTwo = new Button("2");
		btnTwo.setActionCommand("2");
		
		btnThree = new Button("3");
		btnThree.setActionCommand("3");
		
		btnFour = new Button("4");
		btnFour.setActionCommand("4");
		
		btnFive = new Button("5");
		btnFive.setActionCommand("5");
		
		btnSix = new Button("6");
		btnSix.setActionCommand("6");
		
		btnSeven = new Button("7");
		btnSeven.setActionCommand("7");
		
		btnEight = new Button("8");
		btnEight.setActionCommand("8");
		
		btnNine = new Button("9");
		btnNine.setActionCommand("9");
		
		// Add components to the frame
		add(new Label("Operand 1:"));
		add(txtOp1);
		add(new Label("Operand 2:"));
		add(txtOp2);
		add(new Label("Result:"));
		add(txtRes);
		
//		All Buttons
		add(btnAdd);
		add(btnSub);
		add(btnMul);
		add(btnDiv);
		add(btnZero);
		add(btnOne);
		add(btnTwo);
		add(btnThree);
		add(btnFour);
		add(btnFive);
		add(btnSix);
		add(btnSeven);
		add(btnEight);
		add(btnNine);
		
		setTitle("AWT Calculator");
		setLocation(200, 200);
		setSize(200, 220);
	}

	/**
	 * Gets the text from the first operand TextField.
	 * @return The first operand as a String.
	 */
	public String getOperand1() {
		return txtOp1.getText();
	}

	/**
	 * Gets the text from the second operand TextField.
	 * @return The second operand as a String.
	 */
	public String getOperand2() {
		return txtOp2.getText();
	}
	
	public String appendOperand1(String value) {
	    String updated = txtOp1.getText() + value;
	    txtOp1.setText(updated);
	    return updated;
	}

	public String appendOperand2(String value) {
	    String updated = txtOp2.getText() + value;
	    txtOp2.setText(updated);
	    return updated;
	}

	/**
	 * Updates the result TextField with the given result string.
	 * @param result The result to display.
	 */
	public void updateResult(String result) {
		txtRes.setText(result);
	}
	
	
	public String getResultText() {
	    return txtRes.getText();
	}

	/**
	 * Sets the ActionListener for the button.
	 * @param al The ActionListener to be all operations.
	 */
	public void setActionListener(ActionListener al) {
		btnAdd.addActionListener(al);
		btnSub.addActionListener(al);
		btnMul.addActionListener(al);
		btnDiv.addActionListener(al);
		btnOne.addActionListener(al);
		btnTwo.addActionListener(al);
		btnThree.addActionListener(al);
		btnFour.addActionListener(al);
		btnFive.addActionListener(al);
		btnSix.addActionListener(al);
		btnSeven.addActionListener(al);
		btnEight.addActionListener(al);
		btnNine.addActionListener(al);
		btnZero.addActionListener(al);
	}
}
