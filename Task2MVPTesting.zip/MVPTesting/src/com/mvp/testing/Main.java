package com.mvp.testing;

import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * The main application class.
 * This class creates and connects the Model, View, and Presenter.
 */
public class Main {
	public static void main(String[] args) {
		CalculatorModel model = new CalculatorModel();
		CalculatorView view = new CalculatorView();
		CalculatorPresentor presenter = new CalculatorPresentor(model, view);
		view.setActionListener(presenter);

		// Add a WindowListener to handle the window close event
		view.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0); // Exit the application when the window is closed
			}
		});

		view.setVisible(true);
	}
} 

