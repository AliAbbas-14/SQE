package com.mvp.testing;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * The Presenter, responsible for handling user input and coordinating the Model and View.
 * It implements the ActionListener interface to respond to button clicks.
 */
public class CalculatorPresentor implements ActionListener {

	public CalculatorModel model;
	private CalculatorView view;
	
	public CalculatorPresentor(CalculatorModel model, CalculatorView view) {
		this.model = model;
		this.view = view;
	}

	/**
	 * This method is called when a user action occurs (e.g., button click).
	 * It determines which action was performed and executes the appropriate logic.
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		String cmd = e.getActionCommand();
		switch (e.getActionCommand()) {
		case "0":
	    case "1":
	    case "2":
	    case "3":
	    case "4":
	    case "5":
	    case "6":
	    case "7":
	    case "8":
	    case "9":
	    	if (view.getOperand1().isEmpty()) {
                view.appendOperand1(cmd);
            } else {
                view.appendOperand2(cmd);
            }
            break;
		case "Add":
			try {
				double op1 = Double.parseDouble(view.getOperand1());
				double op2 = Double.parseDouble(view.getOperand2());
				double result = model.add(op1, op2);
				view.updateResult(String.valueOf(result));
			} catch (NumberFormatException ex) {
				view.updateResult("Error: Invalid input");
			}
			break;
		case "Sub":
			try {
				double op1 = Double.parseDouble(view.getOperand1());
				double op2 = Double.parseDouble(view.getOperand2());
				double result = model.sub(op1, op2);
				view.updateResult(String.valueOf(result));
			} catch (NumberFormatException ex) {
				view.updateResult("Error: Invalid input");
			}
			break;
		case "Mul":
			try {
				double op1 = Double.parseDouble(view.getOperand1());
				double op2 = Double.parseDouble(view.getOperand2());
				double result = model.mul(op1, op2);
				view.updateResult(String.valueOf(result));
			} catch (NumberFormatException ex) {
				view.updateResult("Error: Invalid input");
			}
			break;
		case "Div":
			try {
				double op1 = Double.parseDouble(view.getOperand1());
				double op2 = Double.parseDouble(view.getOperand2());
				double result = model.div(op1, op2);
				view.updateResult(String.valueOf(result));
			} catch (NumberFormatException ex) {
				view.updateResult("Error: Invalid input");
			}
			break;
		default:
			break;
		}
	}
}

